package com.example.testeditorandviewer.SQLiteOrmClasses.DAO;

import android.database.SQLException;
import com.j256.ormlite.dao.BaseDaoImpl;
import com.j256.ormlite.support.ConnectionSource;

import java.util.List;

public class CustomDAO<T> extends BaseDaoImpl<T, Integer> {

    public CustomDAO(ConnectionSource connectionSource,
                     Class<T> dataClass) throws SQLException, java.sql.SQLException {
        super(connectionSource, dataClass);
    }

    public void Create(T t) {
        try
        {
            this.create(t);
        }catch (Exception ex){}

    }
}