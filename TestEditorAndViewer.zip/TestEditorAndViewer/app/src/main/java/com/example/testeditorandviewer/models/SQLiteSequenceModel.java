package com.example.testeditorandviewer.models;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "sqlite_sequence")
public class SQLiteSequenceModel {
    @DatabaseField(columnName = "name")
    public String name;
    @DatabaseField(columnName = "seq")
    public int seq;
}
