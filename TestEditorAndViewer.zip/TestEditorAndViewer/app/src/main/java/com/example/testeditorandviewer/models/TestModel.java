package com.example.testeditorandviewer.models;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "Tests")
public class TestModel {
    @DatabaseField(generatedId = true)
    public int Id;
    @DatabaseField(canBeNull = false,columnName = "TestOrder")
    public int TestOrder;
    @DatabaseField(canBeNull = false)
    public String Name;
    @DatabaseField(canBeNull = false)
    public String Description;

    @Override
    public String toString() {
        return "TestModel{" +
                "Id=" + Id +
                ", TestOrder=" + TestOrder;
    }
}
