package com.example.testeditorandviewer.models;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "WordAnswers")
public class WordAnswerModel {
    @DatabaseField(generatedId = true)
    public int Id;
    @DatabaseField(canBeNull = false,columnName = "QuestionId")
    public int QuestionId;
    @DatabaseField(canBeNull = false)
    public String TrueWordAnswer;

}
