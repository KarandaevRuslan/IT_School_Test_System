package com.example.testeditorandviewer.SQLiteOrmClasses;

import com.example.testeditorandviewer.SQLiteOrmClasses.DatabaseHelper;
import com.j256.ormlite.android.apptools.OpenHelperManager;

public class HelperFactory {
    private static DatabaseHelper databaseHelper;

    public static DatabaseHelper getHelper(){
        return databaseHelper;
    }
    public static void setHelper(DatabaseHelper dbHelper){
        databaseHelper = dbHelper;
    }
    public static void releaseHelper(){
        OpenHelperManager.releaseHelper();
        databaseHelper = null;
    }
}
