package com.example.testeditorandviewer.activities;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.testeditorandviewer.Other.Answer;
import com.example.testeditorandviewer.R;
import com.example.testeditorandviewer.SQLiteOrmClasses.DAO.CustomDAO;
import com.example.testeditorandviewer.SQLiteOrmClasses.DatabaseHelper;
import com.example.testeditorandviewer.SQLiteOrmClasses.HelperFactory;
import com.example.testeditorandviewer.models.AnswerModel;
import com.example.testeditorandviewer.models.QuestionModel;
import com.example.testeditorandviewer.models.TestModel;
import com.example.testeditorandviewer.models.WordAnswerModel;
import com.j256.ormlite.stmt.DeleteBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

public class QuestionActivity extends AppCompatActivity {
    final int SELECT_QUESTION_IMAGE=0;
    final int SELECT_QUESTION_AUDIO=1;
    final int REQUEST_CODE_FILLER=100;
    final int TIME_IN_MILLISECONDS = 1500;


    EditText questionName,answerWord,points,time;
    ImageButton buttonAddAnswer,deleteImage,deleteAudio;
    RadioGroup responseRadio;
    RecyclerView recyclerView;
    LinearLayout exList,textViewsLayout;
    TextView twQuestion,twPoints,twTime;

    ArrayList<Answer> answers;
    DatabaseHelper helperDB;
    CustomDAO<QuestionModel> questionDAO;
    CustomDAO<TestModel> testDAO;
    CustomDAO<AnswerModel> answerDAO;
    CustomDAO<WordAnswerModel> wordAnswerDAO;
    MyTimer timer;
    int questionId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question_activity);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        helperDB= HelperFactory.getHelper();
        answers=new ArrayList<>();
        try {
            questionDAO=helperDB.getQuestionDAO();
            testDAO=helperDB.getTestDAO();
            answerDAO=helperDB.getAnswerDAO();
            wordAnswerDAO=helperDB.getWordAnswerDAO();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        recyclerView =findViewById(R.id.question_activity_answers);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new AnswerAdapter(this));

        Intent intent=getIntent();
        questionId=intent.getExtras().getInt("questionId");

        questionName =findViewById(R.id.question_activity_question);
        responseRadio=findViewById(R.id.question_activity_response_type);
        answerWord=findViewById(R.id.question_activity_answer_word);
        buttonAddAnswer=findViewById(R.id.question_activity_add);
        points=findViewById(R.id.question_activity_points);
        exList=findViewById(R.id.question_activity_expandable_list);
        time=findViewById(R.id.question_activity_time);
        deleteImage=findViewById(R.id.question_activity_image_delete);
        textViewsLayout=findViewById(R.id.question_activity_text_views_layout);
        twPoints=findViewById(R.id.question_activity_points_tw);
        twQuestion=findViewById(R.id.question_activity_question_tw);
        twTime=findViewById(R.id.question_activity_time_tw);
        deleteAudio=findViewById(R.id.question_activity_audio_delete);

        responseRadio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                int radioButtonId=radioGroup.getCheckedRadioButtonId();
                View radioButton=radioGroup.findViewById(radioButtonId);
                int index=radioGroup.indexOfChild(radioButton);
                SubOnChangeSelectedResponseType(index+1);
            }
        });

        timer=new MyTimer(0,0,null);

        ItemTouchHelper itemTouchHelper=new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP|ItemTouchHelper.DOWN,ItemTouchHelper.LEFT|ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder dragged, @NonNull RecyclerView.ViewHolder target) {
                int position_dragged=dragged.getAdapterPosition();
                int position_target= target.getAdapterPosition();

                Collections.swap(answers,position_dragged,position_target);

                try {
                    AnswerModel draggedModel = answerDAO.queryForId(GetAnswerId(position_dragged+1));
                    AnswerModel targetModel = answerDAO.queryForId(GetAnswerId(position_target+1));

                    draggedModel.AnswerOrder=position_target+1;
                    targetModel.AnswerOrder=position_dragged+1;

                    answerDAO.update(draggedModel);
                    answerDAO.update(targetModel);

                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }

                recyclerView.getAdapter().notifyItemMoved(position_dragged,position_target);
                recyclerView.getAdapter().notifyItemChanged(position_dragged);
                recyclerView.getAdapter().notifyItemChanged(position_target);

                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder swiped, int direction) {
                int position_swiped= swiped.getAdapterPosition();
                DeleteAnswer(position_swiped+1);
            }
        });
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        //| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);



        try {
            QuestionModel question=GetCurrentQuestion();
            questionName.setText(question.Question);
            points.setText(String.valueOf(question.Points));
            time.setText(String.valueOf(question.Time));

            if(question.PathToPicture==null)
            {
                deleteImage.setVisibility(View.GONE);
            }
            else
            {
                deleteImage.setVisibility(View.VISIBLE);
            }

            if(question.PathToAudio==null)
            {
                deleteAudio.setVisibility(View.GONE);
            }
            else
            {
                deleteAudio.setVisibility(View.VISIBLE);
            }

            ((RadioButton)responseRadio.getChildAt(question.ResponseType-1)).setChecked(true);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            QuestionModel question=GetCurrentQuestion();
            question.Question=String.valueOf(questionName.getText());

            try {
                question.Points=Integer.parseInt(String.valueOf(points.getText()));
            }catch (NumberFormatException e){question.Points=1;}
            try {
                int t=Integer.parseInt(String.valueOf(time.getText()));
                if (t<=0)t=1;
                question.Time=t;
            }catch (NumberFormatException e){question.Time=120;}

            questionDAO.update(question);
            switch(question.ResponseType)
            {
                case 1:
                    DeleteBuilder<AnswerModel,Integer> deleteBuilder1 = answerDAO.deleteBuilder();
                    deleteBuilder1.where().eq("QuestionId",questionId);
                    deleteBuilder1.delete();

                    WordAnswerModel wordAnswer=wordAnswerDAO.queryBuilder().where().eq("QuestionId",questionId).queryForFirst();
                    wordAnswer.TrueWordAnswer=String.valueOf(answerWord.getText());
                    wordAnswerDAO.update(wordAnswer);
                    break;
                case 2:
                    int k=0;
                    for (int i=0;i<answers.size();i++)
                    {
                        if(k==1&&answers.get(i).isTrue==1)
                        {
                            answers.get(i).isTrue=0;
                        }
                        else if(answers.get(i).isTrue==1)
                        {
                            k++;
                        }
                    }
                    if(k==0&&answers.size()!=0)
                    {
                        answers.get(0).isTrue=1;
                    }
                case 3:
                    DeleteBuilder<WordAnswerModel,Integer> deleteBuilder2 = wordAnswerDAO.deleteBuilder();
                    deleteBuilder2.where().eq("QuestionId",questionId);
                    deleteBuilder2.delete();

                    ArrayList<AnswerModel>answerModels=GetAnswers();
                    for (int i = 0; i < answerModels.size(); i++) {
                        answerModels.get(i).Answer=answers.get(i).answerText;
                        answerModels.get(i).IsTrue=answers.get(i).isTrue;
                        answerDAO.update(answerModels.get(i));
                    }
                    break;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    //

    private void InsertAnswer(int answerOrder){
        try {
            ArrayList<AnswerModel> answerModels=new ArrayList<>(answerDAO.queryBuilder().where().ge("AnswerOrder",answerOrder).and().eq("QuestionId",questionId).query());
            for (int i = 0; i < answerModels.size(); i++) {
                answerModels.get(i).AnswerOrder++;
            }
            for (AnswerModel a:
                    answerModels) {
                answerDAO.update(a);
            }

            AnswerModel answer=new AnswerModel();
            answer.Answer="Новый ответ";
            answer.QuestionId=questionId;
            answer.IsTrue=0;
            answer.AnswerOrder=answerOrder;
            answerDAO.create(answer);

            answers.add(answerOrder-1,new Answer(answer.Answer,answer.IsTrue));
            recyclerView.getAdapter().notifyDataSetChanged();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private void DeleteAnswer(int answerOrder)
    {
        try {
            DeleteBuilder<AnswerModel,Integer> deleteBuilder = answerDAO.deleteBuilder();
            deleteBuilder.where().eq("AnswerOrder",answerOrder).and().eq("QuestionId",questionId);
            deleteBuilder.delete();

            ArrayList<AnswerModel> answerModels=new ArrayList<>(answerDAO.queryBuilder().where().gt("AnswerOrder",answerOrder).and().eq("QuestionId",questionId).query());
            for (int i = 0; i < answerModels.size(); i++) {
                answerModels.get(i).AnswerOrder--;
            }
            for (AnswerModel a:
                    answerModels) {
                answerDAO.update(a);
            }

            answers.remove(answerOrder-1);
            recyclerView.getAdapter().notifyDataSetChanged();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private ArrayList<AnswerModel> GetAnswers(){
        try {
            ArrayList<AnswerModel>answerModels=new ArrayList<>(answerDAO.queryBuilder().orderBy("AnswerOrder",true).where().eq("QuestionId",questionId).query());
            return answerModels;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }

    }
    private QuestionModel GetCurrentQuestion() throws SQLException {
        return questionDAO.queryBuilder().where().eq("Id",questionId).query().get(0);
    }
    private int GetAnswerId(int answerOrder){
        try {
            return answerDAO.queryBuilder().where().eq("AnswerOrder",answerOrder).and().eq("QuestionId",questionId).queryForFirst().Id;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return 0;
        }

    }

    //

    private void SubOnChangeSelectedResponseType(int responseType) //SOCSRT
    {
        try {
            QuestionModel question=GetCurrentQuestion();
            question.ResponseType=responseType;
            questionDAO.update(question);
            switch (responseType)
            {
                case 1:
                    recyclerView.setVisibility(View.GONE);
                    buttonAddAnswer.setVisibility(View.GONE);
                    answerWord.setVisibility(View.VISIBLE);

                    answers.clear();
                    recyclerView.getAdapter().notifyDataSetChanged();

                    ArrayList<WordAnswerModel>wordAnswers=new ArrayList<>(wordAnswerDAO.queryBuilder().where().eq("QuestionId",questionId).query());
                    if(wordAnswers.size()==0){
                        WordAnswerModel wordAnswer=new WordAnswerModel();
                        wordAnswer.QuestionId=questionId;
                        wordAnswer.TrueWordAnswer="";
                        wordAnswerDAO.create(wordAnswer);
                        answerWord.setText(wordAnswer.TrueWordAnswer);
                    }
                    else {
                        answerWord.setText(wordAnswers.get(0).TrueWordAnswer);
                    }
                    break;
                case 2:
                    recyclerView.setVisibility(View.VISIBLE);
                    buttonAddAnswer.setVisibility(View.VISIBLE);
                    answerWord.setVisibility(View.GONE);

                    ArrayList<AnswerModel> answerModels=Sub2_SOCSRT();
                    answers.clear();
                    for (AnswerModel a:
                            answerModels) {
                        answers.add(new Answer(a.Answer,a.IsTrue));
                    }
                    recyclerView.getAdapter().notifyDataSetChanged();
                    break;
                case 3:
                    recyclerView.setVisibility(View.VISIBLE);
                    buttonAddAnswer.setVisibility(View.VISIBLE);
                    answerWord.setVisibility(View.GONE);

                    ArrayList<AnswerModel> answerModels1=new ArrayList<>(GetAnswers());
                    answers.clear();
                    for (AnswerModel a:
                            answerModels1) {
                        answers.add(new Answer(a.Answer,a.IsTrue));
                    }
                    recyclerView.getAdapter().notifyDataSetChanged();
                    break;

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private ArrayList<AnswerModel> Sub2_SOCSRT()
    {
        try {
            ArrayList<AnswerModel> answerModels=new ArrayList<>(GetAnswers());
            int k=0;
            for (int i=0;i<answerModels.size();i++)
            {
                if(k==1&&answerModels.get(i).IsTrue==1)
                {
                    answerModels.get(i).IsTrue=0;
                    answerDAO.update(answerModels.get(i));
                }
                else if(answerModels.get(i).IsTrue==1)
                {
                    k++;
                }
            }
            if(k==0&&answerModels.size()!=0)
            {
                answerModels.get(0).IsTrue=1;
                answerDAO.update(answerModels.get(0));
            }
            return answerModels;
        }catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }
    }

    public void InsertAnswer(View view) {
        InsertAnswer(1);
    }

    public void ExpandList(View view) {
        if(exList.getVisibility()==View.VISIBLE)
        {
            exList.setVisibility(View.GONE);
        }
        else
        {
            exList.setVisibility(View.VISIBLE);
        }
    }

    public void SetImage(View view) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Выберите изображение"),SELECT_QUESTION_IMAGE);
    }

    public void DeleteImage(View view) throws SQLException {
        QuestionModel question=GetCurrentQuestion();
        question.PathToPicture=null;
        questionDAO.update(question);

        deleteImage.setVisibility(View.GONE);
    }

    public void SetAudio(View view)
    {
        Intent intent = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(Intent.createChooser(intent, "Выберите аудио"),SELECT_QUESTION_AUDIO);
    }

    public void DeleteAudio(View view) throws SQLException {
        QuestionModel question=GetCurrentQuestion();
        question.PathToAudio=null;
        questionDAO.update(question);

        deleteAudio.setVisibility(View.GONE);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(data==null||resultCode==Activity.RESULT_CANCELED)return;

        String truePath=getPath(getApplicationContext(),data.getData());
        String newPath=Environment.getExternalStorageDirectory()+ File.separator+"Tests";
        String[] splitTruePath =truePath.split("/");
        String name=splitTruePath[splitTruePath.length-1];

        File from=new File(truePath);
        File to;
        String fileName;

        try {
            if(requestCode==SELECT_QUESTION_AUDIO)
            {
                fileName=newPath+File.separator+"Audio"+File.separator+name;

                QuestionModel question=GetCurrentQuestion();
                question.PathToAudio=fileName;
                questionDAO.update(question);

                deleteAudio.setVisibility(View.VISIBLE);
            }
            else
            {
                fileName=newPath+File.separator+"Images"+File.separator+name;
                switch (requestCode)
                {
                    case SELECT_QUESTION_IMAGE:
                        QuestionModel question=GetCurrentQuestion();
                        question.PathToPicture=fileName;
                        questionDAO.update(question);

                        deleteImage.setVisibility(View.VISIBLE);
                        break;
                    default:
                        AnswerModel answer=answerDAO.queryBuilder().where().eq("AnswerOrder",requestCode+1-REQUEST_CODE_FILLER).and().eq("QuestionId",questionId).queryForFirst();
                        answer.PathToPicture=fileName;
                        answerDAO.update(answer);

                        recyclerView.getAdapter().notifyItemChanged(requestCode-REQUEST_CODE_FILLER);
                        break;
                }
            }
            to=new File(fileName);
            copy(from,to);
        }catch (Exception e){e.printStackTrace();}
    }

    private Uri GetURI(String pathToImage) throws IOException {
        return Uri.parse(pathToImage).normalizeScheme();
    }

    public void ClearTextQuestion(View view)
    {
        ClearTextCommon(twQuestion,questionName);
    }

    public void ClearTextPoints(View view) {
        ClearTextCommon(twPoints,points);
    }

    public void ClearTextTime(View view) {
        ClearTextCommon(twTime,time);
    }

    private void ClearTextCommon(TextView tw,EditText et)
    {
        timer.cancel();

        int flg=0;
        for (Drawable drw:
                tw.getCompoundDrawables()) {
            if(drw!=null)flg=1;
        }

        if(timer.tw!=null)timer.tw.setCompoundDrawablesWithIntrinsicBounds(null,null,null,null);

        if(flg==0)
        {
            timer=new MyTimer(TIME_IN_MILLISECONDS,TIME_IN_MILLISECONDS,tw);
            timer.start();
            Drawable d = getResources().getDrawable(android.R.drawable.ic_delete);
            tw.setCompoundDrawablesWithIntrinsicBounds(d, null, null,null);
        }
        else
        {

            tw.setCompoundDrawablesWithIntrinsicBounds(null,null,null,null);
            et.setText("");
        }
    }

    class AnswerAdapter extends RecyclerView.Adapter<AnswerAdapter.ViewHolderAnswer>{
        private LayoutInflater inflater;
        public AnswerAdapter(Context context){
            this.inflater = LayoutInflater.from(context);
        }

        @NonNull
        @Override
        public ViewHolderAnswer onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;
            view= inflater.inflate(R.layout.adapter_item_answer, parent, false);
            return new ViewHolderAnswer(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolderAnswer holder, int position) {
            View v=holder.itemView;

            EditText answerText=v.findViewById(R.id.adapter_item_answer_text);
            LinearLayout expandableList=v.findViewById(R.id.adapter_item_answer_expandable_list);
            ImageButton image=v.findViewById(R.id.adapter_item_answer_image);
            ImageButton imageDelete=v.findViewById(R.id.adapter_item_answer_image_delete);
            ImageButton expand=v.findViewById(R.id.adapter_item_answer_expand);
            ImageButton delete=v.findViewById(R.id.adapter_item_answer_delete);
            ImageButton add=v.findViewById(R.id.adapter_item_answer_add);
            ImageButton apply=v.findViewById(R.id.adapter_item_answer_text_apply);
            CheckBox checkBox=v.findViewById(R.id.adapter_item_answer_true);

            int p=holder.getAdapterPosition();
            try {
                AnswerModel answer=answerDAO.queryBuilder().where().eq("AnswerOrder",p+1).and().eq("QuestionId",questionId).query().get(0);
                if(answer.PathToPicture==null)
                {
                    imageDelete.setVisibility(View.GONE);
                }
                else
                {
                    imageDelete.setVisibility(View.VISIBLE);
                }

                Answer ans=answers.get(p);
                answerText.setText(ans.answerText);
                checkBox.setOnCheckedChangeListener(null);
                switch (ans.isTrue)
                {
                    case 0:
                        checkBox.setChecked(false);
                        break;
                    case 1:
                        checkBox.setChecked(true);
                        break;
                }

                QuestionModel question=GetCurrentQuestion();
                switch (question.ResponseType)
                {
                    case 2:
                        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                if(isChecked)
                                {
                                    for (int i=0; i<answers.size();i++) {
                                        if(answers.get(i).isTrue==1)
                                        {
                                            answers.get(i).isTrue=0;
                                            recyclerView.getAdapter().notifyItemChanged(i);
                                        }
                                    }
                                    answers.get(p).isTrue=1;
                                }
                                recyclerView.getAdapter().notifyItemChanged(p);
                            }
                        });
                        break;
                    case 3:
                        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                if(isChecked)
                                {
                                    answers.get(p).isTrue=1;
                                }
                                else
                                {
                                    answers.get(p).isTrue=0;
                                }
                                recyclerView.getAdapter().notifyItemChanged(p);
                            }
                        });
                        break;
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

            add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    InsertAnswer(p+2);
                }
            });

            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DeleteAnswer(p+1);
                }
            });

            apply.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    answers.get(p).answerText=String.valueOf(answerText.getText());
                    recyclerView.getAdapter().notifyItemChanged(p);
                }
            });

            expandableList.setVisibility(View.GONE);
            expand.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(expandableList.getVisibility()==View.VISIBLE)
                    {
                        expandableList.setVisibility(View.GONE);
                    }
                    else
                    {
                        expandableList.setVisibility(View.VISIBLE);
                    }
                }
            });

            image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(intent, "Выберите изображение"),p+REQUEST_CODE_FILLER);
                }
            });

            imageDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        AnswerModel answerModel = answerDAO.queryBuilder().where().eq("AnswerOrder",p+1).and().eq("QuestionId",questionId).query().get(0);
                        answerModel.PathToPicture=null;
                        answerDAO.update(answerModel);

                        recyclerView.getAdapter().notifyItemChanged(p);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }

                }
            });
        }

        @Override
        public int getItemCount() {
            return answers.size();
        }

        public class ViewHolderAnswer extends RecyclerView.ViewHolder {

            ViewHolderAnswer(View view){
                super(view);

            }
        }
    }

    private class MyTimer extends CountDownTimer
    {
        public TextView tw;
        public MyTimer(long millisInFuture, long countDownInterval,TextView tw)
        {
            super(millisInFuture, countDownInterval);
            this.tw=tw;
        }

        @Override
        public void onFinish()
        {
            tw.setCompoundDrawablesWithIntrinsicBounds(null,null,null,null);
        }

        public void onTick(long millisUntilFinished)
        {

        }
    }

    private void copy(File src, File dst) throws IOException {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            InputStream in = new FileInputStream(src);
            try {
                OutputStream out = new FileOutputStream(dst);
                try {
                    // Transfer bytes from in to out
                    byte[] buf = new byte[1024];
                    int len;
                    while ((len = in.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }
                } finally {
                    out.close();
                }
            } finally {
                in.close();
            }
        }
        else if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
        {
            try (InputStream in = new FileInputStream(src)) {
                try (OutputStream out = new FileOutputStream(dst)) {
                    // Transfer bytes from in to out
                    byte[] buf = new byte[1024];
                    int len;
                    while ((len = in.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }
                }
            }
        }
    }

    private String getPath(final Context context, final Uri uri) {
        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/"
                            + split[1];
                }

                // TODO: handle non-primary volumes
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"),
                        Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[] { split[1] };

                return getDataColumn(context, contentUri, selection,
                        selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    private boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri
                .getAuthority());
    }

    private boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri
                .getAuthority());
    }

    private String getDataColumn(Context context, Uri uri,
                                       String selection, String[] selectionArgs) {
        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = { column };

        try {
            cursor = context.getContentResolver().query(uri, projection,
                    selection, selectionArgs, null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor
                        .getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }

    private boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri
                .getAuthority());
    }
}
