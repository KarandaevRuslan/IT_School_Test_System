package com.example.testeditorandviewer.activities;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.testeditorandviewer.SQLiteOrmClasses.DAO.CustomDAO;
import com.example.testeditorandviewer.SQLiteOrmClasses.DatabaseHelper;
import com.example.testeditorandviewer.SQLiteOrmClasses.HelperFactory;
import com.example.testeditorandviewer.R;
import com.example.testeditorandviewer.models.AnswerModel;
import com.example.testeditorandviewer.models.QuestionModel;
import com.example.testeditorandviewer.models.TestModel;
import com.example.testeditorandviewer.models.WordAnswerModel;
import com.j256.ormlite.stmt.DeleteBuilder;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

public class EditorActivity extends AppCompatActivity {
    final int TIME_IN_MILLISECONDS = 1500;
    MyTimer timer;

    EditText testName,testDescription;
    LinearLayout exList,textViews;
    TextView twName,twDescription;
    RecyclerView recyclerView;

    ArrayList<String>questions;
    DatabaseHelper helperDB;
    CustomDAO<QuestionModel> questionDAO;
    CustomDAO<TestModel> testDAO;
    CustomDAO<AnswerModel>answerDAO;
    CustomDAO<WordAnswerModel>wordAnswerDAO;
    int testId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editor_activity);

        helperDB=HelperFactory.getHelper();
        questions=new ArrayList<>();
        try {
            questionDAO=helperDB.getQuestionDAO();
            testDAO=helperDB.getTestDAO();
            answerDAO=helperDB.getAnswerDAO();
            wordAnswerDAO=helperDB.getWordAnswerDAO();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        recyclerView =findViewById(R.id.editor_activity_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new EditorAdapter(this));

        Intent intent=getIntent();
        testId=intent.getExtras().getInt("testId");

        testName =findViewById(R.id.editor_activity_test_name);
        testDescription =findViewById(R.id.editor_activity_test_description);
        exList=findViewById(R.id.editor_activity_expandable_list);
        twName=findViewById(R.id.editor_activity_name_tw);
        twDescription=findViewById(R.id.editor_activity_test_description_tw);
        textViews=findViewById(R.id.editor_activity_test_text_views_layout);

        timer=new MyTimer(0,0,null);

        ItemTouchHelper itemTouchHelper=new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP|ItemTouchHelper.DOWN,ItemTouchHelper.LEFT|ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder dragged, @NonNull RecyclerView.ViewHolder target) {
                int position_dragged=dragged.getAdapterPosition();
                int position_target= target.getAdapterPosition();

                Collections.swap(questions,position_dragged,position_target);

                try {
                    QuestionModel draggedModel = questionDAO.queryForId(GetQuestionId(position_dragged+1));
                    QuestionModel targetModel = questionDAO.queryForId(GetQuestionId(position_target+1));

                    draggedModel.QuestionOrder=position_target+1;
                    targetModel.QuestionOrder=position_dragged+1;

                    questionDAO.update(draggedModel);
                    questionDAO.update(targetModel);

                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }

                recyclerView.getAdapter().notifyItemMoved(position_dragged,position_target);
                recyclerView.getAdapter().notifyItemChanged(position_dragged);
                recyclerView.getAdapter().notifyItemChanged(position_target);

                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder swiped, int direction) {
                int position_swiped= swiped.getAdapterPosition();
                DeleteQuestion(position_swiped+1);
            }
        });
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        //| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);


        try {
            TestModel test=testDAO.queryBuilder().where().eq("Id",testId).query().get(0);
            testName.setText(test.Name);
            testDescription.setText(test.Description);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        ArrayList<QuestionModel> qModels=new ArrayList<>(GetQuestions());
        questions.clear();
        for (QuestionModel q:
                qModels) {
            questions.add(q.Question);
        }
        recyclerView.getAdapter().notifyDataSetChanged();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            TestModel test=testDAO.queryBuilder().where().eq("Id",testId).query().get(0);
            test.Name=String.valueOf(testName.getText());
            test.Description=String.valueOf(testDescription.getText());
            testDAO.update(test);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    //

    private void InsertQuestion(int questionOrder){
        try {
            ArrayList<QuestionModel> questionModels=new ArrayList<>(questionDAO.queryBuilder().where().ge("QuestionOrder",questionOrder).and().eq("TestId",testId).query());
            for (int i = 0; i < questionModels.size(); i++) {
                questionModels.get(i).QuestionOrder++;
            }
            for (QuestionModel q:
                    questionModels) {
                questionDAO.update(q);
            }

            QuestionModel question=new QuestionModel();
            question.Question="Новый вопрос";
            question.Points=1;
            question.Time=120;
            question.TestId=testId;
            question.ResponseType=2;
            question.QuestionOrder=questionOrder;
            questionDAO.create(question);

            questions.add(questionOrder-1,question.Question);
            recyclerView.getAdapter().notifyDataSetChanged();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private void DeleteQuestion(int questionOrder)
    {
        try {
            DeleteBuilder<AnswerModel,Integer> deleteBuilderA = answerDAO.deleteBuilder();
            deleteBuilderA.where().eq("QuestionId",GetQuestionId(questionOrder));
            deleteBuilderA.delete();

            DeleteBuilder<WordAnswerModel,Integer> deleteBuilderWA = wordAnswerDAO.deleteBuilder();
            deleteBuilderWA.where().eq("QuestionId",GetQuestionId(questionOrder));
            deleteBuilderWA.delete();

            DeleteBuilder<QuestionModel,Integer> deleteBuilder = questionDAO.deleteBuilder();
            deleteBuilder.where().eq("QuestionOrder",questionOrder).and().eq("TestId",testId);
            deleteBuilder.delete();

            ArrayList<QuestionModel> questionModels=new ArrayList<>(questionDAO.queryBuilder().where().gt("QuestionOrder",questionOrder).and().eq("TestId",testId).query());
            for (int i = 0; i < questionModels.size(); i++) {
                questionModels.get(i).QuestionOrder--;
            }
            for (QuestionModel q:
                    questionModels) {
                questionDAO.update(q);
            }

            questions.remove(questionOrder-1);
            recyclerView.getAdapter().notifyDataSetChanged();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private ArrayList<QuestionModel> GetQuestions(){
        try {
            ArrayList<QuestionModel>questionModels=new ArrayList<>(questionDAO.queryBuilder().orderBy("QuestionOrder",true).where().eq("TestId",testId).query());
            return questionModels;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }

    }
    private int GetQuestionId(int questionOrder){
        try {
            return questionDAO.queryBuilder().where().eq("QuestionOrder",questionOrder).and().eq("TestId",testId).queryForFirst().Id;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return 0;
        }

    }

    public void InsertQuestion(View view) {
        InsertQuestion(1);
    }

    public void ExpandList(View view) {
        if(exList.getVisibility()==View.VISIBLE)
        {
            exList.setVisibility(View.GONE);
        }
        else
        {
            exList.setVisibility(View.VISIBLE);
        }
    }

    public void StartTest(View view) {
        Intent intent=new Intent(getApplicationContext(),TestTakingActivity.class);
        intent.putExtra("testId",testId);
        startActivity(intent);
    }

    private void ClearTextCommon(TextView tw,EditText et)
    {
        timer.cancel();

        int flg=0;
        for (Drawable drw:
                tw.getCompoundDrawables()) {
            if(drw!=null)flg=1;
        }

        if(timer.tw!=null)timer.tw.setCompoundDrawablesWithIntrinsicBounds(null,null,null,null);

        if(flg==0)
        {
            timer=new MyTimer(TIME_IN_MILLISECONDS,TIME_IN_MILLISECONDS,tw);
            timer.start();
            Drawable d = getResources().getDrawable(android.R.drawable.ic_delete);
            tw.setCompoundDrawablesWithIntrinsicBounds(d, null, null, null);
        }
        else
        {

            tw.setCompoundDrawablesWithIntrinsicBounds(null,null,null,null);
            et.setText("");
        }
    }

    public void ClearTextName(View view) {
        ClearTextCommon(twName,testName);
    }

    public void ClearTextDescription(View view) {
        ClearTextCommon(twDescription,testDescription);
    }

    //

    class EditorAdapter  extends RecyclerView.Adapter<EditorAdapter.ViewHolderEdit>{
        private LayoutInflater inflater;
        public EditorAdapter(Context context){
            this.inflater = LayoutInflater.from(context);
        }

        @NonNull
        @Override
        public ViewHolderEdit onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;
            view= inflater.inflate(R.layout.adapter_item_question, parent, false);
            return new ViewHolderEdit(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolderEdit holder, int position) {
            View v=holder.itemView;
            TextView test=v.findViewById(R.id.adapter_item_question_text);
            ImageButton addQuestion=v.findViewById(R.id.adapter_item_question_add);
            ImageButton deleteQuestion=v.findViewById(R.id.adapter_item_question_delete);
            ImageButton editQuestion=v.findViewById(R.id.adapter_item_question_edit);
            ImageButton expand=v.findViewById(R.id.adapter_item_question_expand);
            LinearLayout expandableList=v.findViewById(R.id.adapter_item_question_expandable_list);

            int p=holder.getAdapterPosition();
            if(questions.get(p)!=null)test.setText(questions.get(p));
            else test.setVisibility(View.GONE);

            addQuestion.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    InsertQuestion(p+2);
                }
            });

            deleteQuestion.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DeleteQuestion(p+1);
                }
            });

            editQuestion.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(getApplicationContext(),QuestionActivity.class);
                    int questionId = GetQuestionId(p+1);
                    intent.putExtra("questionId",questionId);
                    startActivity(intent);
                }
            });

            expandableList.setVisibility(View.GONE);
            expand.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(expandableList.getVisibility()==View.VISIBLE)
                    {
                        expandableList.setVisibility(View.GONE);
                    }
                    else
                    {
                        expandableList.setVisibility(View.VISIBLE);
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return questions.size();
        }

        public class ViewHolderEdit extends RecyclerView.ViewHolder {

            ViewHolderEdit(View view){
                super(view);

            }
        }
    }

    private class MyTimer extends CountDownTimer
    {
        public TextView tw;
        public MyTimer(long millisInFuture, long countDownInterval,TextView tw)
        {
            super(millisInFuture, countDownInterval);
            this.tw=tw;
        }

        @Override
        public void onFinish()
        {
            tw.setCompoundDrawablesWithIntrinsicBounds(null,null,null,null);
        }

        public void onTick(long millisUntilFinished)
        {

        }
    }
}