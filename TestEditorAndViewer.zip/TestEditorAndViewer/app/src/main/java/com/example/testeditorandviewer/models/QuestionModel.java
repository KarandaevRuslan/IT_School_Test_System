package com.example.testeditorandviewer.models;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "Questions")
public class QuestionModel {
    @DatabaseField(generatedId = true)
    public int Id;
    @DatabaseField(canBeNull = false,columnName = "TestId")
    public int TestId;
    @DatabaseField(canBeNull = false,columnName = "QuestionOrder")
    public int QuestionOrder;
    @DatabaseField()
    public String PathToPicture;
    @DatabaseField()
    public String PathToAudio;
    @DatabaseField()
    public String Question;
    @DatabaseField(canBeNull = false)
    public int ResponseType;
    @DatabaseField(canBeNull = false)
    public int Points;
    @DatabaseField(canBeNull = false)
    public int Time;

    @Override
    public String toString() {
        return "QuestionModel{" +
                "Id=" + Id +
                ", TestId=" + TestId +
                ", QuestionOrder=" + QuestionOrder +
                ", Question='" + Question + '\'' +
                '}';
    }
}
