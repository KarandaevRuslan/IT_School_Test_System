package com.example.testeditorandviewer.Other;

import com.example.testeditorandviewer.SQLiteOrmClasses.DAO.CustomDAO;
import com.example.testeditorandviewer.SQLiteOrmClasses.DatabaseHelper;
import com.example.testeditorandviewer.SQLiteOrmClasses.HelperFactory;
import com.example.testeditorandviewer.models.AnswerModel;
import com.example.testeditorandviewer.models.QuestionModel;
import com.example.testeditorandviewer.models.WordAnswerModel;

import java.sql.SQLException;
import java.util.ArrayList;

public class QuestionAndAnswers {
    public QuestionAndAnswers(int questionId)
    {
        this.questionId=questionId;

        DatabaseHelper helperDB;
        CustomDAO<QuestionModel> questionDAO;
        CustomDAO<AnswerModel>answerDAO;
        CustomDAO<WordAnswerModel>wordAnswerDAO;

        helperDB= HelperFactory.getHelper();
        try {
            questionDAO=helperDB.getQuestionDAO();
            answerDAO=helperDB.getAnswerDAO();
            wordAnswerDAO=helperDB.getWordAnswerDAO();

            question=questionDAO.queryForId(questionId);
            questionResponseType=question.ResponseType;
            switch (question.ResponseType)
            {
                case 1:
                    wordAnswer=wordAnswerDAO.queryBuilder().where().eq("QuestionId",questionId).queryForFirst();
                    break;
                default:
                    answers=new ArrayList<>(answerDAO.queryBuilder().orderBy("AnswerOrder",true).where().eq("QuestionId",questionId).query());
                    break;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }
    public int questionId;
    public int questionResponseType;
    public QuestionModel question;
    public ArrayList<AnswerModel>answers;
    public WordAnswerModel wordAnswer;
}
