package com.example.testeditorandviewer.Other;

import com.example.testeditorandviewer.SQLiteOrmClasses.DAO.CustomDAO;
import com.example.testeditorandviewer.SQLiteOrmClasses.DatabaseHelper;
import com.example.testeditorandviewer.SQLiteOrmClasses.HelperFactory;
import com.example.testeditorandviewer.models.AnswerModel;
import com.example.testeditorandviewer.models.QuestionModel;
import com.example.testeditorandviewer.models.TestModel;
import com.example.testeditorandviewer.models.WordAnswerModel;

import java.sql.SQLException;

public class Answer {
    public Answer(String answerText,int isTrue)
    {
        this.answerText=answerText;
        this.isTrue=isTrue;
    }
    public String answerText;
    public int isTrue;
}
