package com.example.testeditorandviewer.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.testeditorandviewer.Other.QuestionAndAnswers;
import com.example.testeditorandviewer.Other.UserResponse;
import com.example.testeditorandviewer.R;
import com.example.testeditorandviewer.SQLiteOrmClasses.DAO.CustomDAO;
import com.example.testeditorandviewer.SQLiteOrmClasses.DatabaseHelper;
import com.example.testeditorandviewer.SQLiteOrmClasses.HelperFactory;
import com.example.testeditorandviewer.models.AnswerModel;
import com.example.testeditorandviewer.models.QuestionModel;
import com.example.testeditorandviewer.models.TestModel;
import com.example.testeditorandviewer.models.WordAnswerModel;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Timer;

public class TestTakingActivity extends AppCompatActivity {
    final String GREEN="#008000";
    final String ORANGE="#ff8c00";
    final String RED="#ff0000";

    LinearLayout testTitle,questionLayout, checkBoxes,results;
    TextView testName,testDescription,order,points,time,questionName,trueWord,result;
    ImageView questionImage,next,previous;
    EditText word;
    RadioGroup radioGroup;

    DatabaseHelper helperDB;
    CustomDAO<QuestionModel> questionDAO;
    CustomDAO<TestModel> testDAO;
    CustomDAO<AnswerModel>answerDAO;
    CustomDAO<WordAnswerModel>wordAnswerDAO;
    TestModel test;
    QuestionAndAnswers questionAndAnswers;
    ArrayList<UserResponse>userResponses;
    MyTimer timer;
    int testId;
    int questionOrder=-1;
    int numberOfQuestions=0;
    int flagCheckResult=0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        //| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        setContentView(R.layout.test_taking_activity);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        Intent intent=getIntent();
        testId=intent.getExtras().getInt("testId");

        helperDB= HelperFactory.getHelper();
        try {
            questionDAO=helperDB.getQuestionDAO();
            testDAO=helperDB.getTestDAO();
            answerDAO=helperDB.getAnswerDAO();
            wordAnswerDAO=helperDB.getWordAnswerDAO();

            test=testDAO.queryForId(testId);
            numberOfQuestions=(int)questionDAO.queryBuilder().where().eq("TestId",testId).countOf();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        userResponses=new ArrayList<>();

        testTitle=findViewById(R.id.test_taking_activity_test_title);
        testName=findViewById(R.id.test_taking_activity_test_name);
        testDescription=findViewById(R.id.test_taking_activity_test_description);
        questionLayout=findViewById(R.id.test_taking_activity_question_layout);
        checkBoxes =findViewById(R.id.test_taking_activity_question_layout_check_boxs);
        order=findViewById(R.id.test_taking_activity_question_layout_order);
        points=findViewById(R.id.test_taking_activity_question_layout_points);
        time=findViewById(R.id.test_taking_activity_question_layout_time);
        word=findViewById(R.id.test_taking_activity_question_layout_word);
        radioGroup=findViewById(R.id.test_taking_activity_question_layout_radio);
        questionName=findViewById(R.id.test_taking_activity_question_layout_question);
        questionImage=findViewById(R.id.test_taking_activity_question_layout_image);
        trueWord=findViewById(R.id.test_taking_activity_question_layout_true_word);
        results=findViewById(R.id.test_taking_activity_results);
        next=findViewById(R.id.test_taking_activity_next);
        result=findViewById(R.id.test_taking_activity_text_result);
        previous=findViewById(R.id.test_taking_activity_previous);

        timer=new MyTimer(0,0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(flagCheckResult==0)
        {
            try {
                SetState();
            } catch (SQLException | IOException throwables) {
                throwables.printStackTrace();
            }
        }
        else
        {
            try {
                SetStateResult();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        if(flagCheckResult==0)NextPage();
    }

    private int GetQuestionId(int questOrder) throws SQLException {
        return questionDAO.queryBuilder().where().eq("TestId",testId).and().eq("QuestionOrder",questOrder).queryForFirst().Id;
    }

    public void NextPage(View view) {
        if(flagCheckResult==0)
        {
            NextPage();
            try {
                SetState();
            } catch (SQLException | IOException throwables) {
                throwables.printStackTrace();
            }
        }
        else
        {
            NextPageResult();
            try {
                SetStateResult();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void NextPage()
    {
        timer.cancel();
        switch(questionOrder)
        {
            case -2:
                break;
            case -1:
                if(numberOfQuestions!=0)questionOrder=1;
                else questionOrder=-2;
                break;
            default:
                switch (questionAndAnswers.question.ResponseType)
                {
                    case 1:
                        userResponses.get(questionOrder-1).wordResponse=String.valueOf(word.getText());
                        break;
                    case 2:
                        if(radioGroup.getChildCount()!=0) userResponses.get(questionOrder-1).orderResponse=radioGroup.indexOfChild(findViewById(radioGroup.getCheckedRadioButtonId()))+1;
                        else userResponses.get(questionOrder-1).orderResponse=0;
                        break;
                    case 3:
                        int count1 = checkBoxes.getChildCount();
                        userResponses.get(questionOrder-1).ordersResponse=new ArrayList<>();
                        if(count1>0) {
                            for (int i=count1-1;i>=0;i--)
                            {
                                View o = checkBoxes.getChildAt(i);
                                if (!(o instanceof CheckBox))continue;

                                if(((CheckBox)o).isChecked())
                                {
                                    userResponses.get(questionOrder-1).ordersResponse.add(i+1);
                                }
                            }
                        }
                        break;
                }
                if(questionOrder==numberOfQuestions)
                {
                    questionOrder=-2;
                }
                else
                {
                    questionOrder++;
                }
                break;
        }
    }
    private void SetState() throws SQLException, IOException {
        switch(questionOrder)
        {
            case -2:
                SetStateCaseResult();
                break;
            case -1:
                questionLayout.setVisibility(View.GONE);
                testTitle.setVisibility(View.VISIBLE);
                results.setVisibility(View.GONE);

                testName.setText(test.Name);
                testDescription.setText(test.Description);
                break;
            default:
                questionLayout.setVisibility(View.VISIBLE);
                testTitle.setVisibility(View.GONE);
                results.setVisibility(View.GONE);

                questionAndAnswers=new QuestionAndAnswers(GetQuestionId(questionOrder));
                questionName.setText(questionAndAnswers.question.Question);
                order.setText(questionOrder+"/"+numberOfQuestions);
                points.setText(questionAndAnswers.question.Points+" балл"+окончаниеСлова_балл(questionAndAnswers.question.Points));
                time.setText(questionAndAnswers.question.Time+" секунд"+окончаниеСлова_секунда(questionAndAnswers.question.Time));
                if(questionAndAnswers.question.PathToPicture!=null)
                {
                    questionImage.setVisibility(View.GONE);
                    //questionImage.setImageURI(GetURI(questionAndAnswers.question.PathToPicture));
                }
                else
                {
                    questionImage.setVisibility(View.GONE);
                }

                timer=new MyTimer(questionAndAnswers.question.Time*1000,1000);
                timer.start();

                userResponses.add(new UserResponse(questionAndAnswers));

                switch (questionAndAnswers.question.ResponseType)
                {
                    case 1:
                        word.setVisibility(View.VISIBLE);
                        radioGroup.setVisibility(View.GONE);
                        checkBoxes.setVisibility(View.GONE);
                        break;
                    case 2:
                        word.setVisibility(View.GONE);
                        radioGroup.setVisibility(View.VISIBLE);
                        checkBoxes.setVisibility(View.GONE);

                        int count = radioGroup.getChildCount();
                        if(count>0) {
                            for (int i=count-1;i>=0;i--) {
                                View o = radioGroup.getChildAt(i);
                                if (o instanceof RadioButton) {
                                    radioGroup.removeViewAt(i);
                                }
                            }
                        }

                        for (AnswerModel ans:
                                questionAndAnswers.answers) {
                            radioGroup.addView(GetRadioButton(ans));
                        }
                        count = radioGroup.getChildCount();
                        if(count!=0)((RadioButton)radioGroup.getChildAt(0)).setChecked(true);

                        break;
                    case 3:
                        word.setVisibility(View.GONE);
                        radioGroup.setVisibility(View.GONE);
                        checkBoxes.setVisibility(View.VISIBLE);

                        int count1 = checkBoxes.getChildCount();
                        if(count1>0) {
                            for (int i=count1-1;i>=0;i--) {
                                View o = checkBoxes.getChildAt(i);
                                if (o instanceof CheckBox) {
                                    checkBoxes.removeViewAt(i);
                                }
                            }
                        }

                        for (AnswerModel ans:
                                questionAndAnswers.answers) {
                            checkBoxes.addView(GetCheckBox(ans));
                        }
                        break;
                }
                break;
        }
    }

    private RadioButton GetRadioButton(AnswerModel ans)
    {
        RadioButton radioButton=new RadioButton(getApplicationContext());
        radioButton.setText(ans.Answer);
        radioButton.setTextSize(14);
        radioButton.setGravity(Gravity.CENTER);
        radioButton.setLayoutParams(new RadioGroup.LayoutParams(RadioGroup.LayoutParams.MATCH_PARENT, RadioGroup.LayoutParams.WRAP_CONTENT));
        return radioButton;
    }
    private CheckBox GetCheckBox(AnswerModel ans)
    {
        CheckBox checkBox=new CheckBox(getApplicationContext());
        checkBox.setText(ans.Answer);
        checkBox.setTextSize(14);
        checkBox.setGravity(Gravity.CENTER);
        checkBox.setLayoutParams(new RadioGroup.LayoutParams(RadioGroup.LayoutParams.MATCH_PARENT, RadioGroup.LayoutParams.WRAP_CONTENT));
        return checkBox;
    }

    private Uri GetURI(String pathToImage) throws IOException {
        return Uri.parse(pathToImage).normalizeScheme();
    }

    private String окончаниеСлова_балл(int num)
    {
        if (num%100/10!=1)
        {
            switch (num%10)
            {
                case 1:
                    return "";
                case 2:
                case 3:
                case 4:
                    return "а";
                default:
                    return "ов";
            }
        }
        else
        {
            return "ов";
        }
    }
    private String окончаниеСлова_секунда(int num)
    {
        if (num%100/10!=1)
        {
            switch (num%10)
            {
                case 1:
                    return "а";
                case 2:
                case 3:
                case 4:
                    return "ы";
                default:
                    return "";
            }
        }
        else
        {
            return "";
        }
    }

    public void Exit(View view) {
        finish();
    }

    public void Retry(View view) {
        Intent intent=new Intent(getApplicationContext(),TestTakingActivity.class);
        intent.putExtra("testId",testId);
        startActivity(intent);
        finish();
    }

    public void SeeResults(View view) {
        if(numberOfQuestions!=0)questionOrder=1;
        try {
            SetStateResult();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void NextPageResult()
    {
        switch(questionOrder)
        {
            default:
                if(questionOrder==numberOfQuestions)
                {
                    questionOrder=-2;
                }
                else
                {
                    questionOrder++;
                }
                break;
        }
    }
    private void SetStateResult() throws SQLException, IOException {
        switch(questionOrder)
        {
            case -2:
                SetStateCaseResult();
                break;
            default:
                if(questionOrder==1)previous.setVisibility(View.GONE);
                else previous.setVisibility(View.VISIBLE);

                next.setVisibility(View.VISIBLE);

                questionLayout.setVisibility(View.VISIBLE);
                testTitle.setVisibility(View.GONE);
                results.setVisibility(View.GONE);
                switch (userResponses.get(questionOrder-1).getIsTrue())
                {
                    case 0:
                        time.setText("Неверный ответ");
                        time.setTextColor(Color.parseColor(RED));
                        break;
                    case 1:
                        time.setText("Верный ответ");
                        time.setTextColor(Color.parseColor(GREEN));
                        break;
                }

                questionAndAnswers=new QuestionAndAnswers(GetQuestionId(questionOrder));
                questionName.setText(questionAndAnswers.question.Question);
                order.setText(questionOrder+"/"+numberOfQuestions);
                points.setText(questionAndAnswers.question.Points+" балл"+окончаниеСлова_балл(questionAndAnswers.question.Points));
                if(questionAndAnswers.question.PathToPicture!=null)
                {
                    questionImage.setVisibility(View.GONE);
                    //questionImage.setImageURI(GetURI(questionAndAnswers.question.PathToPicture));
                }
                else
                {
                    questionImage.setVisibility(View.GONE);
                }

                switch (questionAndAnswers.question.ResponseType)
                {
                    case 1:
                        word.setVisibility(View.VISIBLE);

                        word=(EditText) MakeNoEditable(word);

                        if(userResponses.get(questionOrder-1).wordResponse.equals(userResponses.get(questionOrder-1).getTrueWordResponse()))
                        {
                            word.setText(userResponses.get(questionOrder-1).wordResponse);
                            word.setTextColor(Color.parseColor(GREEN));
                        }
                        else
                        {
                            trueWord.setVisibility(View.VISIBLE);
                            trueWord.setTextColor(Color.parseColor(GREEN));
                            trueWord.setText(userResponses.get(questionOrder-1).getTrueWordResponse());

                            word.setText(userResponses.get(questionOrder-1).wordResponse);
                            word.setTextColor(Color.parseColor(RED));
                        }

                        radioGroup.setVisibility(View.GONE);
                        checkBoxes.setVisibility(View.GONE);
                        break;
                    case 2:
                        word.setVisibility(View.GONE);
                        trueWord.setVisibility(View.GONE);
                        radioGroup.setVisibility(View.VISIBLE);
                        checkBoxes.setVisibility(View.GONE);

                        int count = radioGroup.getChildCount();
                        if(count>0) {
                            for (int i=count-1;i>=0;i--) {
                                View o = radioGroup.getChildAt(i);
                                if (o instanceof RadioButton) {
                                    radioGroup.removeViewAt(i);
                                }
                            }
                        }

                        for (AnswerModel ans:
                                questionAndAnswers.answers) {
                            radioGroup.addView(GetRadioButtonForResult(ans));
                        }

                        break;
                    case 3:
                        word.setVisibility(View.GONE);
                        trueWord.setVisibility(View.GONE);
                        radioGroup.setVisibility(View.GONE);
                        checkBoxes.setVisibility(View.VISIBLE);

                        int count1 = checkBoxes.getChildCount();
                        if(count1>0) {
                            for (int i=count1-1;i>=0;i--) {
                                View o = checkBoxes.getChildAt(i);
                                if (o instanceof CheckBox) {
                                    checkBoxes.removeViewAt(i);
                                }
                            }
                        }

                        for (AnswerModel ans:
                                questionAndAnswers.answers) {
                            checkBoxes.addView(GetCheckBoxForResult(ans));
                        }
                        break;
                }
                break;
        }
    }

    private void SetStateCaseResult()
    {
        questionLayout.setVisibility(View.GONE);
        testTitle.setVisibility(View.GONE);
        results.setVisibility(View.VISIBLE);
        next.setVisibility(View.GONE);
        if(numberOfQuestions!=0)previous.setVisibility(View.VISIBLE);

        int userPoints=0;
        int maxPoints=0;
        int userTrueQuestions=0;
        for (UserResponse u:
                userResponses) {
            userPoints+=u.getPoints();
            maxPoints+=u.getPointsForCorrectAnswer();
            userTrueQuestions+=u.getIsTrue();
        }
        result.setText(userPoints+" из "+maxPoints+" баллов");
        if(maxPoints!=0)result.append("\n"+(userPoints*100/maxPoints)+" % баллов");
        result.append("\n\n"+userTrueQuestions+" из "+numberOfQuestions+" верно");
        if(numberOfQuestions!=0)result.append("\n"+(userTrueQuestions*100/numberOfQuestions)+" % верно");
        flagCheckResult=1;
    }

    private RadioButton GetRadioButtonForResult(AnswerModel ans){
        RadioButton radioButton=new RadioButton(getApplicationContext());

        radioButton=(RadioButton) MakeNoEditable(radioButton);

        if(ans.IsTrue==1)
        {
            radioButton.setTextColor(Color.parseColor(GREEN));
//            if(userResponses.get(questionOrder-1).orderResponse==ans.AnswerOrder)
//                radioButton.setTextColor(Color.parseColor(GREEN));
        }
        else if(ans.IsTrue==0&&userResponses.get(questionOrder-1).orderResponse==ans.AnswerOrder)
        {
            radioButton.setTextColor(Color.parseColor(RED));
        }
        if(userResponses.get(questionOrder-1).orderResponse==ans.AnswerOrder)
        {
            radioButton.setChecked(true);
        }

        radioButton.setText(ans.Answer);
        radioButton.setTextSize(14);
        radioButton.setGravity(Gravity.CENTER);
        radioButton.setLayoutParams(new RadioGroup.LayoutParams(RadioGroup.LayoutParams.MATCH_PARENT, RadioGroup.LayoutParams.WRAP_CONTENT));
        return radioButton;
    }

    private CheckBox GetCheckBoxForResult(AnswerModel ans)
    {
        CheckBox checkBox=new CheckBox(getApplicationContext());

        checkBox=(CheckBox) MakeNoEditable(checkBox);

        if(ans.IsTrue==1)
        {
            checkBox.setTextColor(Color.parseColor(GREEN));
//            if(userResponses.get(questionOrder-1).ordersResponse.contains(ans.AnswerOrder))
//                checkBox.setTextColor(Color.parseColor(GREEN));
        }
        else if(ans.IsTrue==0&&userResponses.get(questionOrder-1).ordersResponse.contains(ans.AnswerOrder))
        {
            checkBox.setTextColor(Color.parseColor(RED));
        }
        if(userResponses.get(questionOrder-1).ordersResponse.contains(ans.AnswerOrder))
        {
            checkBox.setChecked(true);
        }

        checkBox.setText(ans.Answer);
        checkBox.setTextSize(14);
        checkBox.setGravity(Gravity.CENTER);
        checkBox.setLayoutParams(new RadioGroup.LayoutParams(RadioGroup.LayoutParams.MATCH_PARENT, RadioGroup.LayoutParams.WRAP_CONTENT));
        return checkBox;
    }

    private View MakeNoEditable(View v)
    {
        v.setFocusable(false);
        v.setFocusableInTouchMode(false);
        v.setClickable(false);
        return v;
    }

    public void PreviousPageResult(View view) {
        switch(questionOrder)
        {
            case -2:
                if(numberOfQuestions!=0)questionOrder=numberOfQuestions;
                break;
            default:
                questionOrder--;
                break;
        }
        try {
            SetStateResult();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class MyTimer extends CountDownTimer
    {

        public MyTimer(long millisInFuture, long countDownInterval)
        {
            super(millisInFuture, countDownInterval);
        }

        @Override
        public void onFinish()
        {
            NextPage();
            try {
                SetState();
            } catch (SQLException | IOException throwables) {
                throwables.printStackTrace();
            }
        }

        public void onTick(long millisUntilFinished)
        {
            String t=String.valueOf(time.getText());
            int ti=Integer.parseInt(t.split(" ")[0]);
            time.setText(String.valueOf(ti-1)+" секунд"+окончаниеСлова_секунда(ti-1));
        }
    }
}
