package com.example.testeditorandviewer.models;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;


@DatabaseTable(tableName = "Answers")
public class AnswerModel {
    @DatabaseField(generatedId = true)
    public int Id;
    @DatabaseField(canBeNull = false,columnName = "QuestionId")
    public int QuestionId;
    @DatabaseField(canBeNull = false,columnName = "AnswerOrder")
    public int AnswerOrder;
    @DatabaseField()
    public String PathToPicture;
    @DatabaseField()
    public String Answer;
    @DatabaseField(canBeNull = false)
    public int IsTrue;

}
