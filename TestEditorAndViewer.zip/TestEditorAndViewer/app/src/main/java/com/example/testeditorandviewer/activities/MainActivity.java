package com.example.testeditorandviewer.activities;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.testeditorandviewer.R;
import com.example.testeditorandviewer.SQLiteOrmClasses.DAO.CustomDAO;
import com.example.testeditorandviewer.SQLiteOrmClasses.DatabaseHelper;
import com.example.testeditorandviewer.SQLiteOrmClasses.HelperFactory;
import com.example.testeditorandviewer.models.AnswerModel;
import com.example.testeditorandviewer.models.QuestionModel;
import com.example.testeditorandviewer.models.TestModel;
import com.example.testeditorandviewer.models.WordAnswerModel;
import com.j256.ormlite.stmt.DeleteBuilder;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    LinearLayout exList;

    ArrayList<String>tests;
    DatabaseHelper helperDB;
    CustomDAO<TestModel> testDAO;
    CustomDAO<AnswerModel>answerDAO;
    CustomDAO<WordAnswerModel>wordAnswerDAO;
    CustomDAO<QuestionModel> questionDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        //| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        helperDB= HelperFactory.getHelper();
        tests=new ArrayList<>();
        try {
            questionDAO=helperDB.getQuestionDAO();
            testDAO=helperDB.getTestDAO();
            answerDAO=helperDB.getAnswerDAO();
            wordAnswerDAO=helperDB.getWordAnswerDAO();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        recyclerView =findViewById(R.id.activity_main_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new MainAdapter(this));

        exList=findViewById(R.id.activity_main_expandable_list);

        ItemTouchHelper itemTouchHelper=new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP|ItemTouchHelper.DOWN,ItemTouchHelper.LEFT|ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder dragged, @NonNull RecyclerView.ViewHolder target) {
                int position_dragged=dragged.getAdapterPosition();
                int position_target= target.getAdapterPosition();

                Collections.swap(tests,position_dragged,position_target);

                try {
                    TestModel draggedModel = testDAO.queryForId(GetTestId(position_dragged+1));
                    TestModel targetModel = testDAO.queryForId(GetTestId(position_target+1));

                    draggedModel.TestOrder=position_target+1;
                    targetModel.TestOrder=position_dragged+1;

                    testDAO.update(draggedModel);
                    testDAO.update(targetModel);

                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }

                recyclerView.getAdapter().notifyItemMoved(position_dragged,position_target);
                recyclerView.getAdapter().notifyItemChanged(position_dragged);
                recyclerView.getAdapter().notifyItemChanged(position_target);

                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder swiped, int direction) {
                int position_swiped= swiped.getAdapterPosition();
                DeleteTest(position_swiped+1);
            }
        });
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ArrayList<TestModel> tModels=new ArrayList<>(GetTests());
        tests.clear();
        for (TestModel t:
                tModels) {
            tests.add(t.Name);
        }
        recyclerView.getAdapter().notifyDataSetChanged();
    }
    //

    private void InsertTest(int testOrder){
        try {
            ArrayList<TestModel> testModels=new ArrayList<>(testDAO.queryBuilder().where().ge("TestOrder",testOrder).query());
            for (int i = 0; i < testModels.size(); i++) {
                testModels.get(i).TestOrder++;
            }
            for (TestModel t:
                    testModels) {
                testDAO.update(t);
            }

            TestModel test=new TestModel();
            test.Name="Новый тест";
            test.Description="";
            test.TestOrder=testOrder;
            testDAO.create(test);

            tests.add(testOrder-1,test.Name);
            recyclerView.getAdapter().notifyDataSetChanged();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private void DeleteTest(int testOrder)
    {
        try {
            ArrayList<QuestionModel>questionModels=new ArrayList<>(questionDAO.queryBuilder().where().eq("TestId",GetTestId(testOrder)).query());
            for (QuestionModel q:
                 questionModels) {
                DeleteQuestion(q.Id);
            }

            DeleteBuilder<TestModel,Integer> deleteBuilder = testDAO.deleteBuilder();
            deleteBuilder.where().eq("TestOrder",testOrder);
            deleteBuilder.delete();

            ArrayList<TestModel> testModels=new ArrayList<>(testDAO.queryBuilder().where().gt("TestOrder",testOrder).query());
            for (int i = 0; i < testModels.size(); i++) {
                testModels.get(i).TestOrder--;
            }
            for (TestModel t:
                    testModels) {
                testDAO.update(t);
            }

            tests.remove(testOrder-1);
            recyclerView.getAdapter().notifyDataSetChanged();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private void DeleteQuestion(int questionId) throws SQLException {
        DeleteBuilder<AnswerModel,Integer> deleteBuilderA = answerDAO.deleteBuilder();
        deleteBuilderA.where().eq("QuestionId",questionId);
        deleteBuilderA.delete();

        DeleteBuilder<WordAnswerModel,Integer> deleteBuilderWA = wordAnswerDAO.deleteBuilder();
        deleteBuilderWA.where().eq("QuestionId",questionId);
        deleteBuilderWA.delete();

        questionDAO.deleteById(questionId);
    }
    private ArrayList<TestModel> GetTests(){
        try {
            ArrayList<TestModel>testModels=new ArrayList<>(testDAO.queryBuilder().orderBy("TestOrder",true).query());
            return testModels;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }

    }
    private int GetTestId(int testOrder){
        try {
            return testDAO.queryBuilder().where().eq("TestOrder",testOrder).query().get(0).Id;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return 0;
        }

    }

    //

    public void InsertTest(View view) {
        InsertTest(1);
    }

    public void ExpandList(View view) {
        if(exList.getVisibility()==View.VISIBLE)
        {
            exList.setVisibility(View.GONE);
        }
        else
        {
            exList.setVisibility(View.VISIBLE);
        }
    }

    //

    class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolderMain>{
        private LayoutInflater inflater;

        public MainAdapter(Context context){
            this.inflater = LayoutInflater.from(context);
        }

        @NonNull
        @Override
        public ViewHolderMain onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;
            view= inflater.inflate(R.layout.adapter_item_test, parent, false);
            return new ViewHolderMain(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolderMain holder, int position) {
            View v=holder.itemView;
            TextView test=v.findViewById(R.id.adapter_item_test_text);
            ImageButton addTest=v.findViewById(R.id.adapter_item_test_add);
            ImageButton deleteTest=v.findViewById(R.id.adapter_item_test_delete);
            ImageButton editTest=v.findViewById(R.id.adapter_item_test_edit);
            ImageButton start=v.findViewById(R.id.adapter_item_test_start);
            ImageButton expand=v.findViewById(R.id.adapter_item_test_expand);
            LinearLayout expandableList=v.findViewById(R.id.adapter_item_test_expandable_list);

            int p=holder.getAdapterPosition();
            test.setText(tests.get(p));

            addTest.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    InsertTest(p+2);
                }
            });

            deleteTest.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DeleteTest(p+1);
                }
            });

            editTest.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(getApplicationContext(),EditorActivity.class);
                    int testId = GetTestId(p+1);
                    intent.putExtra("testId",testId);
                    startActivity(intent);
                }
            });

            start.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(getApplicationContext(),TestTakingActivity.class);
                    intent.putExtra("testId",GetTestId(p+1));
                    startActivity(intent);
                }
            });

            expandableList.setVisibility(View.GONE);
            expand.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(expandableList.getVisibility()==View.VISIBLE)
                    {
                        expandableList.setVisibility(View.GONE);
                    }
                    else
                    {
                        expandableList.setVisibility(View.VISIBLE);
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return tests.size();
        }

        public class ViewHolderMain extends RecyclerView.ViewHolder {

            ViewHolderMain(View v){
                super(v);
            }
        }
    }
}