package com.example.testeditorandviewer.activities;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.testeditorandviewer.R;
import com.example.testeditorandviewer.SQLiteOrmClasses.DAO.CustomDAO;
import com.example.testeditorandviewer.SQLiteOrmClasses.DatabaseHelper;
import com.example.testeditorandviewer.SQLiteOrmClasses.HelperFactory;
import com.example.testeditorandviewer.models.AnswerModel;
import com.example.testeditorandviewer.models.QuestionModel;
import com.example.testeditorandviewer.models.SQLiteSequenceModel;
import com.example.testeditorandviewer.models.TestModel;
import com.example.testeditorandviewer.models.WordAnswerModel;
import com.j256.ormlite.stmt.DeleteBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {
    final int IMPORT = 0;
    RecyclerView recyclerView;
    LinearLayout exList;

    ArrayList<String>tests;
    DatabaseHelper helperDB;
    CustomDAO<TestModel> testDAO;
    CustomDAO<AnswerModel>answerDAO;
    CustomDAO<WordAnswerModel>wordAnswerDAO;
    CustomDAO<QuestionModel> questionDAO;
    CustomDAO<SQLiteSequenceModel>sqLiteSequenceDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        helperDB= HelperFactory.getHelper();
        tests=new ArrayList<>();
        try {
            questionDAO=helperDB.getQuestionDAO();
            testDAO=helperDB.getTestDAO();
            answerDAO=helperDB.getAnswerDAO();
            wordAnswerDAO=helperDB.getWordAnswerDAO();
            sqLiteSequenceDAO=helperDB.getSqLiteSequenceDAO();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        recyclerView =findViewById(R.id.activity_main_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new MainAdapter(this));

        exList=findViewById(R.id.activity_main_expandable_list);

        ItemTouchHelper itemTouchHelper=new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP|ItemTouchHelper.DOWN,ItemTouchHelper.LEFT|ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder dragged, @NonNull RecyclerView.ViewHolder target) {
                int position_dragged=dragged.getAdapterPosition();
                int position_target= target.getAdapterPosition();

                Collections.swap(tests,position_dragged,position_target);

                try {
                    TestModel draggedModel = testDAO.queryForId(GetTestId(position_dragged+1));
                    TestModel targetModel = testDAO.queryForId(GetTestId(position_target+1));

                    draggedModel.TestOrder=position_target+1;
                    targetModel.TestOrder=position_dragged+1;

                    testDAO.update(draggedModel);
                    testDAO.update(targetModel);

                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }

                recyclerView.getAdapter().notifyItemMoved(position_dragged,position_target);
                recyclerView.getAdapter().notifyItemChanged(position_dragged);
                recyclerView.getAdapter().notifyItemChanged(position_target);

                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder swiped, int direction) {
                int position_swiped= swiped.getAdapterPosition();
                DeleteTest(position_swiped+1);
            }
        });
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        //| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);


        ArrayList<TestModel> tModels=new ArrayList<>(GetTests());
        tests.clear();
        for (TestModel t:
                tModels) {
            tests.add(t.Name);
        }
        recyclerView.getAdapter().notifyDataSetChanged();
    }
    //

    private void InsertTest(int testOrder){
        try {
            ArrayList<TestModel> testModels=new ArrayList<>(testDAO.queryBuilder().where().ge("TestOrder",testOrder).query());
            for (int i = 0; i < testModels.size(); i++) {
                testModels.get(i).TestOrder++;
            }
            for (TestModel t:
                    testModels) {
                testDAO.update(t);
            }

            TestModel test=new TestModel();
            test.Name="Новый тест";
            test.Description="";
            test.TestOrder=testOrder;
            testDAO.create(test);

            tests.add(testOrder-1,test.Name);
            recyclerView.getAdapter().notifyDataSetChanged();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private void DeleteTest(int testOrder)
    {
        try {
            ArrayList<QuestionModel>questionModels=new ArrayList<>(questionDAO.queryBuilder().where().eq("TestId",GetTestId(testOrder)).query());
            for (QuestionModel q:
                 questionModels) {
                DeleteQuestion(q.Id);
            }

            DeleteBuilder<TestModel,Integer> deleteBuilder = testDAO.deleteBuilder();
            deleteBuilder.where().eq("TestOrder",testOrder);
            deleteBuilder.delete();

            ArrayList<TestModel> testModels=new ArrayList<>(testDAO.queryBuilder().where().gt("TestOrder",testOrder).query());
            for (int i = 0; i < testModels.size(); i++) {
                testModels.get(i).TestOrder--;
            }
            for (TestModel t:
                    testModels) {
                testDAO.update(t);
            }

            tests.remove(testOrder-1);
            recyclerView.getAdapter().notifyDataSetChanged();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private void DeleteQuestion(int questionId) throws SQLException {
        DeleteBuilder<AnswerModel,Integer> deleteBuilderA = answerDAO.deleteBuilder();
        deleteBuilderA.where().eq("QuestionId",questionId);
        deleteBuilderA.delete();

        DeleteBuilder<WordAnswerModel,Integer> deleteBuilderWA = wordAnswerDAO.deleteBuilder();
        deleteBuilderWA.where().eq("QuestionId",questionId);
        deleteBuilderWA.delete();

        questionDAO.deleteById(questionId);
    }
    private ArrayList<TestModel> GetTests(){
        try {
            ArrayList<TestModel>testModels=new ArrayList<>(testDAO.queryBuilder().orderBy("TestOrder",true).query());
            return testModels;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }

    }
    private int GetTestId(int testOrder){
        try {
            return testDAO.queryBuilder().where().eq("TestOrder",testOrder).query().get(0).Id;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return 0;
        }

    }

    //

    public void InsertTest(View view) {
        InsertTest(1);
    }

    public void ExpandList(View view) {
        if(exList.getVisibility()==View.VISIBLE)
        {
            exList.setVisibility(View.GONE);
        }
        else
        {
            exList.setVisibility(View.VISIBLE);
        }
    }

    public void Import(View view) {
        Intent intent=new Intent(getApplicationContext(),AndroidExplorer.class);
        startActivityForResult(intent,IMPORT);
    }

    private int GetLastId(String tableName) throws SQLException {

        ArrayList<SQLiteSequenceModel>table=new ArrayList<>(sqLiteSequenceDAO.queryBuilder().where().eq("name",tableName).query());
        if(table.size()==0)return 0;
        else return table.get(0).seq;
    }

    private String GetFileName(String path)
    {
        if (path==null)return null;
        String[] splitPath =path.split("/");
        return splitPath[splitPath.length-1];
    }

    private void copy(File src, File dst) throws IOException {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            InputStream in = new FileInputStream(src);
            try {
                OutputStream out = new FileOutputStream(dst);
                try {
                    // Transfer bytes from in to out
                    byte[] buf = new byte[1024];
                    int len;
                    while ((len = in.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }
                } finally {
                    out.close();
                }
            } finally {
                in.close();
            }
        }
        else if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
        {
            try (InputStream in = new FileInputStream(src)) {
                try (OutputStream out = new FileOutputStream(dst)) {
                    // Transfer bytes from in to out
                    byte[] buf = new byte[1024];
                    int len;
                    while ((len = in.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }
                }
            }
        }
    }

    private String getPath(final Context context, final Uri uri) {
        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/"
                            + split[1];
                }

                // TODO: handle non-primary volumes
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"),
                        Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[] { split[1] };

                return getDataColumn(context, contentUri, selection,
                        selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    private boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri
                .getAuthority());
    }

    private boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri
                .getAuthority());
    }


    private String getDataColumn(Context context, Uri uri,
                                 String selection, String[] selectionArgs) {
        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = { column };

        try {
            cursor = context.getContentResolver().query(uri, projection,
                    selection, selectionArgs, null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor
                        .getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }

    private boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri
                .getAuthority());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(data==null||resultCode== Activity.RESULT_CANCELED)return;

        switch (requestCode)
        {
            case IMPORT:
                String directory=data.getExtras().getString("directory");
                String dbName=data.getExtras().getString("dbname");

                try {
                    String appDirectory=Environment.getExternalStorageDirectory()+File.separator+"Tests";
                    int lastTestId=GetLastId("Tests");
                    int countTest=(int)testDAO.countOf();
                    String pathDB=directory+File.separator+dbName;

                    DatabaseHelper newDB=new DatabaseHelper(getApplicationContext(),pathDB);
                    CustomDAO<TestModel>testModelCustomDAO=newDB.getTestDAO();
                    CustomDAO<QuestionModel>questionModelCustomDAO=newDB.getQuestionDAO();
                    CustomDAO<AnswerModel>answerModelCustomDAO=newDB.getAnswerDAO();
                    CustomDAO<WordAnswerModel>wordAnswerModelCustomDAO=newDB.getWordAnswerDAO();

                    TestModel testModel=testModelCustomDAO.queryForFirst();
                    countTest++;
                    lastTestId++;
                    testModel.TestOrder=countTest;
                    testDAO.create(testModel);
                    tests.add(testModel.Name);
                    recyclerView.getAdapter().notifyDataSetChanged();

                    ArrayList<QuestionModel> questionModels=new ArrayList<>(questionModelCustomDAO.queryForAll());

                    int lastQId=GetLastId("Questions");
                    lastQId++;
                    for (QuestionModel qm: questionModels) {
                        if(qm.PathToPicture!=null)
                        {
                            copy(new File(directory+File.separator+"Images"+File.separator+qm.PathToPicture),new File(appDirectory+File.separator+"Images"+File.separator+qm.PathToPicture));
                            qm.PathToPicture=appDirectory+File.separator+"Images"+File.separator+qm.PathToPicture;
                        }
                        if(qm.PathToAudio!=null)
                        {
                            copy(new File(directory+File.separator+"Audio"+File.separator+qm.PathToAudio),new File(appDirectory+File.separator+"Audio"+File.separator+qm.PathToAudio));
                            qm.PathToAudio=appDirectory+File.separator+"Audio"+File.separator+qm.PathToAudio;
                        }

                        qm.TestId=lastTestId;

                        switch (qm.ResponseType)
                        {
                            case 1:
                                WordAnswerModel wordAnswerModel=wordAnswerModelCustomDAO.queryBuilder().where().eq("QuestionId",qm.Id).queryForFirst();
                                wordAnswerModel.QuestionId=lastQId;
                                wordAnswerDAO.create(wordAnswerModel);
                                break;
                            default:
                                ArrayList<AnswerModel>answerModels=new ArrayList<>(answerModelCustomDAO.queryBuilder().where().eq("QuestionId",qm.Id).query());
                                for (AnswerModel ans:
                                        answerModels) {
                                    if(ans.PathToPicture!=null)
                                    {
                                        copy(new File(directory+File.separator+"Images"+File.separator+ans.PathToPicture),new File(appDirectory+File.separator+"Images"+File.separator+ans.PathToPicture));
                                        ans.PathToPicture=appDirectory+File.separator+"Images"+File.separator+ans.PathToPicture;
                                    }

                                    ans.QuestionId=lastQId;
                                    answerDAO.create(ans);
                                }
                                break;
                        }

                        questionDAO.create(qm);

                        lastQId++;
                    }
                } catch (SQLException | IOException throwables) {
                    throwables.printStackTrace();
                }
                break;
        }
    }

    //

    class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolderMain>{
        private LayoutInflater inflater;

        public MainAdapter(Context context){
            this.inflater = LayoutInflater.from(context);
        }

        @NonNull
        @Override
        public ViewHolderMain onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;
            view= inflater.inflate(R.layout.adapter_item_test, parent, false);
            return new ViewHolderMain(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolderMain holder, int position) {
            View v=holder.itemView;
            TextView test=v.findViewById(R.id.adapter_item_test_text);
            ImageButton addTest=v.findViewById(R.id.adapter_item_test_add);
            ImageButton deleteTest=v.findViewById(R.id.adapter_item_test_delete);
            ImageButton editTest=v.findViewById(R.id.adapter_item_test_edit);
            ImageButton start=v.findViewById(R.id.adapter_item_test_start);
            ImageButton expand=v.findViewById(R.id.adapter_item_test_expand);
            ImageButton export=v.findViewById(R.id.adapter_item_test_export);
            LinearLayout expandableList=v.findViewById(R.id.adapter_item_test_expandable_list);

            int p=holder.getAdapterPosition();
            test.setText(tests.get(p));

            addTest.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    InsertTest(p+2);
                }
            });

            deleteTest.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DeleteTest(p+1);
                }
            });

            editTest.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(getApplicationContext(),EditorActivity.class);
                    int testId = GetTestId(p+1);
                    intent.putExtra("testId",testId);
                    startActivity(intent);
                }
            });

            start.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(getApplicationContext(),TestTakingActivity.class);
                    intent.putExtra("testId",GetTestId(p+1));
                    startActivity(intent);
                }
            });

            export.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        int newTestId=GetTestId(p+1);
                        TestModel testModel=testDAO.queryForId(newTestId);
                        String pathTestDirectory=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)+File.separator+testModel.Name;
                        if(new File(pathTestDirectory).exists())
                        {
                            int k=1;
                            while(new File(pathTestDirectory+String.valueOf(k)).exists())
                            {
                                k++;
                            }
                            pathTestDirectory+=String.valueOf(k);
                        }

                        File exportedTestDirectory=new File(pathTestDirectory);
                        exportedTestDirectory.mkdir();
                        File imagesDirectory=new File(pathTestDirectory+File.separator+"Images");
                        imagesDirectory.mkdir();
                        File audioDirectory=new File(pathTestDirectory+File.separator+"Audio");
                        audioDirectory.mkdir();

                        DatabaseHelper newDB=new DatabaseHelper(getApplicationContext(),pathTestDirectory+File.separator+"Database.db");
                        CustomDAO<TestModel>testModelCustomDAO=newDB.getTestDAO();
                        CustomDAO<QuestionModel>questionModelCustomDAO=newDB.getQuestionDAO();
                        CustomDAO<AnswerModel>answerModelCustomDAO=newDB.getAnswerDAO();
                        CustomDAO<WordAnswerModel>wordAnswerModelCustomDAO=newDB.getWordAnswerDAO();

                        testModel.TestOrder=1;
                        testModelCustomDAO.create(testModel);

                        ArrayList<QuestionModel> questionModels=new ArrayList<>(questionDAO.queryBuilder().where().eq("TestId",newTestId).query());

                        int qId=1;
                        for (QuestionModel qm:
                             questionModels) {
                            if(qm.PathToPicture!=null)copy(new File(qm.PathToPicture),new File(pathTestDirectory+File.separator+"Images"+File.separator+GetFileName(qm.PathToPicture)));
                            if(qm.PathToAudio!=null)copy(new File(qm.PathToAudio),new File(pathTestDirectory+File.separator+"Audio"+File.separator+GetFileName(qm.PathToAudio)));
                            qm.PathToPicture=GetFileName(qm.PathToPicture);
                            qm.PathToAudio=GetFileName(qm.PathToAudio);
                            qm.TestId=1;

                            switch (qm.ResponseType)
                            {
                                case 1:
                                    WordAnswerModel wordAnswerModel=wordAnswerDAO.queryBuilder().where().eq("QuestionId",qm.Id).queryForFirst();
                                    wordAnswerModel.QuestionId=qId;
                                    wordAnswerModelCustomDAO.create(wordAnswerModel);
                                    break;
                                default:
                                    ArrayList<AnswerModel>answerModels=new ArrayList<>(answerDAO.queryBuilder().where().eq("QuestionId",qm.Id).query());
                                    for (AnswerModel ans:
                                         answerModels) {
                                        if(ans.PathToPicture!=null)copy(new File(ans.PathToPicture),new File(pathTestDirectory+File.separator+"Images"+File.separator+GetFileName(ans.PathToPicture)));
                                        ans.PathToPicture=GetFileName(ans.PathToPicture);

                                        ans.QuestionId=qId;
                                        answerModelCustomDAO.create(ans);
                                    }
                                    break;
                            }

                            questionModelCustomDAO.create(qm);

                            qId++;
                        }

                        Toast.makeText(getApplicationContext(),"Экспортированный тест расположен по пути: "+pathTestDirectory,Toast.LENGTH_LONG).show();
                    } catch (SQLException | IOException throwables) {
                        throwables.printStackTrace();
                    }
                }
            });

            expandableList.setVisibility(View.GONE);
            expand.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(expandableList.getVisibility()==View.VISIBLE)
                    {
                        expandableList.setVisibility(View.GONE);
                    }
                    else
                    {
                        expandableList.setVisibility(View.VISIBLE);
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return tests.size();
        }

        public class ViewHolderMain extends RecyclerView.ViewHolder {

            ViewHolderMain(View v){
                super(v);
            }
        }
    }
}