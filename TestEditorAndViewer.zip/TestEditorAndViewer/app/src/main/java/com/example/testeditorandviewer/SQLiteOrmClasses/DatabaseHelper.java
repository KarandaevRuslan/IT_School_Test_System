package com.example.testeditorandviewer.SQLiteOrmClasses;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.example.testeditorandviewer.SQLiteOrmClasses.DAO.CustomDAO;
import com.example.testeditorandviewer.models.AnswerModel;
import com.example.testeditorandviewer.models.QuestionModel;
import com.example.testeditorandviewer.models.TestModel;
import com.example.testeditorandviewer.models.WordAnswerModel;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

public class DatabaseHelper extends OrmLiteSqliteOpenHelper {

    private static final String TAG = DatabaseHelper.class.getSimpleName();

    //с каждым увеличением версии, при нахождении в устройстве БД с предыдущей версией будет выполнен метод onUpgrade();
    private static final int DATABASE_VERSION = 1;

    //ссылки на DAO соответсвующие сущностям, хранимым в БД
    private CustomDAO<TestModel> testDAO = null;
    private CustomDAO<QuestionModel> questionDAO = null;
    private CustomDAO<AnswerModel> answerDAO = null;
    private CustomDAO<WordAnswerModel> wordAnswerDAO = null;

    public DatabaseHelper(Context context, String pathDB){
        super(context, pathDB, null, DATABASE_VERSION);
    }

    //Выполняется, когда файл с БД не найден на устройстве
    @Override
    public void onCreate(SQLiteDatabase db, ConnectionSource connectionSource){
        try
        {
            TableUtils.createTable(connectionSource, TestModel.class);
            TableUtils.createTable(connectionSource, QuestionModel.class);
            TableUtils.createTable(connectionSource, AnswerModel.class);
            TableUtils.createTable(connectionSource, WordAnswerModel.class);
        }
        catch (SQLException | java.sql.SQLException e){
            throw new RuntimeException(e);
        }
    }

    //Выполняется, когда БД имеет версию отличную от текущей
    @Override
    public void onUpgrade(SQLiteDatabase db, ConnectionSource connectionSource, int oldVer, int newVer){
        try{
            //Так делают ленивые, гораздо предпочтительнее не удаляя БД аккуратно вносить изменения
            TableUtils.dropTable(connectionSource, TestModel.class, true);
            TableUtils.dropTable(connectionSource, QuestionModel.class, true);
            TableUtils.dropTable(connectionSource, AnswerModel.class, true);
            TableUtils.dropTable(connectionSource, WordAnswerModel.class, true);
            onCreate(db, connectionSource);
        }
        catch (SQLException | java.sql.SQLException e){
            throw new RuntimeException(e);
        }
    }

    //синглтон для QuestionDAO
    public CustomDAO<TestModel> getTestDAO() throws SQLException, java.sql.SQLException {
            if(testDAO == null){
                testDAO = new CustomDAO<>(getConnectionSource(), TestModel.class);
            }
            return testDAO;
        }
    public CustomDAO<QuestionModel> getQuestionDAO() throws SQLException, java.sql.SQLException {
        if(questionDAO == null){
            questionDAO = new CustomDAO<>(getConnectionSource(), QuestionModel.class);
        }
        return questionDAO;
    }
    public CustomDAO<AnswerModel> getAnswerDAO() throws SQLException, java.sql.SQLException {
        if(answerDAO == null){
            answerDAO = new CustomDAO<>(getConnectionSource(), AnswerModel.class);
        }
        return answerDAO;
    }
    public CustomDAO<WordAnswerModel> getWordAnswerDAO() throws SQLException, java.sql.SQLException {
        if(wordAnswerDAO == null){
            wordAnswerDAO = new CustomDAO<>(getConnectionSource(), WordAnswerModel.class);
        }
        return wordAnswerDAO;
    }

    //выполняется при закрытии приложения
    @Override
    public void close(){
        super.close();
        testDAO=null;
        questionDAO = null;
        answerDAO=null;
        wordAnswerDAO=null;
    }
}
