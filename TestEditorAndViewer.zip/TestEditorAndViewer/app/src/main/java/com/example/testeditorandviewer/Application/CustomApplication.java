package com.example.testeditorandviewer.Application;

import android.app.Application;
import android.os.Build;
import android.os.Environment;
import android.provider.ContactsContract;

import com.example.testeditorandviewer.SQLiteOrmClasses.DatabaseHelper;
import com.example.testeditorandviewer.SQLiteOrmClasses.HelperFactory;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

public class CustomApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onLowMemory() {
        terminateFunction();
        super.onLowMemory();
    }

    @Override
    public void onTerminate() {
        terminateFunction();
        super.onTerminate();
    }

    private void terminateFunction()
    {
//        try{
//            HelperFactory.getHelper().getTestDAO().delete(HelperFactory.getHelper().getTestDAO().queryForAll());
//        }catch (Exception ex){}
        HelperFactory.releaseHelper();
    }
}
