package com.example.testeditorandviewer.Other;

import android.util.Log;
import android.widget.Toast;

import com.example.testeditorandviewer.models.AnswerModel;

import java.util.ArrayList;

public class UserResponse {

    public UserResponse(QuestionAndAnswers qAA)
    {
        SetTrueAnswers(qAA);
    }

    private int responseType;
    public int getResponseType() {
        return responseType;
    }

    private int questionId;
    public int getQuestionId() {
        return questionId;
    }

    public String wordResponse; //1
    private String trueWordResponse;
    public String getTrueWordResponse() {
        return trueWordResponse;
    }

    public int orderResponse; //2
    private int trueOrderResponse;
    public int getTrueOrderResponse() {
        return trueOrderResponse;
    }

    public ArrayList<Integer>ordersResponse; //3
    private ArrayList<Integer>trueOrdersResponse;
    public ArrayList<Integer> getTrueOrdersResponse() {
        return trueOrdersResponse;
    }

    private int pointsForCorrectAnswer;
    public int getPointsForCorrectAnswer() {
        return pointsForCorrectAnswer;
    }
    private int points=0;
    public int getPoints() {
        if(flag==1)return points;

        switch (responseType)
        {
            case 1:
                if(!wordResponse.equals(trueWordResponse))
                {
                    flag=1;
                    isTrue=0;
                    return 0;
                }
                break;
            case 2:
                if(orderResponse!=trueOrderResponse)
                {
                    flag=1;
                    isTrue=0;
                    return 0;
                }
                break;
            case 3:
                if(ordersResponse.size()==0&&trueOrdersResponse.size()==0)
                {
                    flag=1;
                    isTrue=1;
                    return pointsForCorrectAnswer;
                }
                else if(ordersResponse.size()==0)
                {
                    flag=1;
                    isTrue=0;
                    return 0;
                }
                for (Integer ordResp:
                     ordersResponse) {
                    if(!trueOrdersResponse.contains(ordResp))
                    {
                        flag=1;
                        isTrue=0;
                        return 0;
                    }
                }
                break;
        }
        flag=1;
        isTrue=1;
        points=pointsForCorrectAnswer;
        return points;
    }
    private int isTrue=0;
    public int getIsTrue() {
        return isTrue;
    }

    int flag=0;

    private void SetTrueAnswers(QuestionAndAnswers questionAndAnswers)
    {
        questionId=questionAndAnswers.questionId;
        responseType=questionAndAnswers.questionResponseType;
        pointsForCorrectAnswer=questionAndAnswers.question.Points;

        switch (responseType)
        {
            case 1:
                trueWordResponse=questionAndAnswers.wordAnswer.TrueWordAnswer;
                break;
            case 2:
                for (AnswerModel ans:
                questionAndAnswers.answers)
                {
                    if(ans.IsTrue==1)
                    {
                        trueOrderResponse=ans.AnswerOrder;
                        break;
                    }
                }
                break;
            case 3:
                trueOrdersResponse=new ArrayList<>();
                for (AnswerModel ans:
                        questionAndAnswers.answers)
                {
                    if(ans.IsTrue==1)
                    {
                        trueOrdersResponse.add(ans.AnswerOrder);
                    }
                }
                break;
        }
        return;
    }
}
