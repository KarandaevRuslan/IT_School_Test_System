package com.example.testeditorandviewer.activities;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.testeditorandviewer.R;

public class AndroidExplorer extends ListActivity {

    private List<String> item = null;
    private List<String> path = null;
    private String root;
    private TextView myPath;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        //| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        setContentView(R.layout.file_exploer_layout);
        myPath = findViewById(R.id.path);
        root=String.valueOf(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));
        getDir(root);

        Toast.makeText(getApplicationContext(),"Выберите файл с расширением \".db\".",Toast.LENGTH_SHORT).show();
    }

    private void getDir(String dirPath)
    {
        myPath.setText("Вы находитесь в: " + dirPath);
        item = new ArrayList<String>();
        path = new ArrayList<String>();

        File f = new File(dirPath);
        File[] files = f.listFiles();

        if(!dirPath.equals(root))
        {
            item.add(root);
            path.add(root);
            item.add("../");
            path.add(f.getParent());
        }

        for(int i=0; i < files.length; i++)
        {
            File file = files[i];
            path.add(file.getPath());
            if(file.isDirectory())
                item.add(file.getName() + "/");
            else
                item.add(file.getName());
        }

        ArrayAdapter<String> fileList =
                new ArrayAdapter<String>(this, R.layout.row, item);
        setListAdapter(fileList);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        File file = new File(path.get(position));

        if (file.isDirectory())
        {
            if(file.canRead())
                getDir(path.get(position));
            else
            {
                new AlertDialog.Builder(this)
                        .setIcon(R.drawable.app_icon)
                        .setTitle("[" + file.getName() + "] folder can't be read!")
                        .setPositiveButton("OK",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // TODO Auto-generated method stub
                                    }
                                }).show();
            }
        }
        else
        {
            String[]splitPath=path.get(position).split("/");
            String name=splitPath[splitPath.length-1];
            String extension=name.split("\\.")[1];

            if(!extension.equals("db"))
            {
                Toast.makeText(getApplicationContext(),"Данный файл не имеет расширение \".db\"! Выберите файл с расширением \".db\"!",Toast.LENGTH_SHORT).show();
                return;
            }

            String dir=path.get(position).substring(0,path.get(position).length()-name.length()-1);

            if(!new File(dir+File.separator+"Audio").exists())
            {
                Toast.makeText(getApplicationContext(),"Отсутствует папка \"Audio\"",Toast.LENGTH_SHORT).show();
                return;
            }
            if(!new File(dir+File.separator+"Images").exists())
            {
                Toast.makeText(getApplicationContext(),"Отсутствует папка \"Images\"",Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent=new Intent();
            intent.putExtra("directory",dir);
            intent.putExtra("dbname",name);
            setResult(RESULT_OK,intent);
            finish();
        }
    }
}